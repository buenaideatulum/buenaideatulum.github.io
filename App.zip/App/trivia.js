const questions = [
    {
        question: "¿Cómo es la receta del Aldos Clasic?",
        options: [
            "Nutella, azúcar glass, galletas clásicas, oblea, crema batida, granillo combinado y gelato",
            "Chocolate, sal, oblea, galleta oreo y gelato",
            "No sé"
        ],
        correctAnswer: 0
    },
    {
        question: "¿Cuáles son los pasos de servicio en vitrina?",
        options: [
            "Cobrar, dar la bienvenida y despedir",
            "Bienvenida a Aldos + prueba de los 2 segundos, romper el hielo, labor de venta, toma y entrega de comanda, preparación y entrega del producto",
            "No sé"
        ],
        correctAnswer: 1
    }
];

let currentQuestionIndex = 0;
let score = 0;
let username = "";

// Función para iniciar el juego
function startGame() {
    const usernameInput = document.getElementById("usernameInput").value;
    if (usernameInput.trim() !== "") {
        username = usernameInput;
        document.getElementById("username").innerText = username;
        document.getElementById("usernameScreen").style.display = "none";
        showGameElements();  // Mostrar los elementos del juego
        setQuestion();
    } else {
        alert("Por favor, ingresa un nombre de usuario.");
    }
}

function showGameElements() {
    document.getElementById("header").classList.remove("hidden");
    document.getElementById("gameTitle").classList.remove("hidden");
    document.getElementById("question").classList.remove("hidden");
    document.getElementById("options").classList.remove("hidden");
}

function updateScore() {
    const scoreElement = document.getElementById("score");
    // Limitar a dos dígitos el marcador
    scoreElement.innerText = score >= 0 ? String(score).padStart(2, '0') : String(score).padStart(3, '0');
}

function setQuestion() {
    const currentQuestion = questions[currentQuestionIndex];
    document.getElementById("question").innerText = currentQuestion.question;
    document.getElementById("option1").innerText = currentQuestion.options[0];
    document.getElementById("option2").innerText = currentQuestion.options[1];
    document.getElementById("option3").innerText = currentQuestion.options[2];
}

function showCorrectMessage() {
    const correctMessage = document.getElementById("correctMessage");
    correctMessage.style.display = "block";
    correctMessage.classList.add("flash");

    // Ocultar el contenido de la pantalla mientras se muestra el mensaje de correcto
    document.getElementById("question").classList.add("hidden");
    document.getElementById("options").classList.add("hidden");

    // Sumar 1 punto en caso de respuesta correcta
    score++;
    updateScore();

    setTimeout(() => {
        correctMessage.classList.remove("flash");
        correctMessage.style.display = "none";
        currentQuestionIndex++;
        if (currentQuestionIndex < questions.length) {
            setQuestion();  // Mostrar la siguiente pregunta
            document.getElementById("question").classList.remove("hidden");
            document.getElementById("options").classList.remove("hidden");
        } else {
            showFinalScreen();  // Mostrar pantalla final
        }
    }, 2000);  // Tiempo para mostrar el mensaje de "¡CORRECTO!" antes de continuar
}

function showIncorrectMessage() {
    const incorrectMessage = document.getElementById("incorrectMessage");
    incorrectMessage.style.display = "block";
    incorrectMessage.classList.add("flash-incorrect");

    // Ocultar el contenido de la pantalla mientras se muestra el mensaje de incorrecto
    document.getElementById("question").classList.add("hidden");
    document.getElementById("options").classList.add("hidden");

    // Restar 1 punto en caso de respuesta incorrecta
    score--;
    updateScore();

    setTimeout(() => {
        incorrectMessage.classList.remove("flash-incorrect");
        incorrectMessage.style.display = "none";
        document.getElementById("question").classList.remove("hidden");
        document.getElementById("options").classList.remove("hidden");
    }, 1000);  // Tiempo para mostrar el mensaje de "¡INCORRECTO!" antes de continuar
}

function checkAnswer(selectedOption) {
    const currentQuestion = questions[currentQuestionIndex];
    if (selectedOption === currentQuestion.correctAnswer) {
        showCorrectMessage();
    } else {
        showIncorrectMessage();
    }
}

function showFinalScreen() {
    document.getElementById("question").classList.add("hidden");
    document.getElementById("options").classList.add("hidden");
    document.getElementById("gameTitle").classList.add("hidden");
    document.getElementById("finalUsername").innerText = `Usuario: ${username}`;
    document.getElementById("finalScore").innerText = `Puntuación: ${score}`;
    document.getElementById("finalScreen").style.display = "block";
    startConfetti();
}

function startConfetti() {
    const confettiContainer = document.getElementById("confetti");
    const colors = ['#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FFA500', '#800080'];
    
    for (let i = 0; i < 100; i++) {
        const confettiPiece = document.createElement("div");
        confettiPiece.className = "confetti-piece";
        confettiPiece.style.width = `${Math.random() * 15 + 5}px`;
        confettiPiece.style.height = `${Math.random() * 15 + 5}px`;
        confettiPiece.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
        confettiPiece.style.top = `${Math.random() * 100}vh`;
        confettiPiece.style.left = `${Math.random() * 100}vw`;
        confettiPiece.style.animation = `confetti-fall ${Math.random() * 3 + 2}s linear`;
        confettiContainer.appendChild(confettiPiece);
    }
}
